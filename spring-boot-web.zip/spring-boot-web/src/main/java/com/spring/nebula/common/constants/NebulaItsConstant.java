package com.spring.nebula.common.constants;

public interface NebulaItsConstant {

	//本地（windows环境）
	String email_file_basepath="src/main/resources/static/file/";
	//阿里云
	//String email_file_basepath="/usr/local/nebula/spring-nebula-web/file/";
	
}
