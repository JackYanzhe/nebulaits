package com.spring.nebula.common.annotation;

import org.springframework.stereotype.Repository;

@Repository
public @interface MysqlRepository {
}
